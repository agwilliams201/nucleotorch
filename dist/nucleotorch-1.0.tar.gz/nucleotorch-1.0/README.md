# nucleotorch
Convert FASTQ reads to binary PyTorch tensors!
